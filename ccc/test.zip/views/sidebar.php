<div class="mail-sidebar">
	<div class="mail-sidebar__tab">
		<p>Почта</p>
	</div>
	<div class="mail-sidebar__menu">
		<div class="mail-sidebar__menu_table">
			<table cellspacing="0">
				<tr>
					<td><a href="">Входящие</a></td><td>счетчик 1</td>
				</tr>
				<tr>
					<td><a href="">Отправленные</td><td>счетчик 2</td>
				</tr>
			</table>
		</div>
	</div>
</div>